#include"Tile.h"

Tile::Tile()
	:tileID(0)
{
}

Tile::Tile(unsigned int ID)
	:tileID(ID)
{
}